Dewiers Overlay - Forge 1.8.9

What it does:
- Cancels the vanilla block-selection outline.
- Draws a translucent black overlay on the selected block.
- Uses the profile color 0x72000000 (ARGB), i.e. alpha 114/255.

Build:
1. Use Java 8 for ForgeGradle 2.1.
2. Put this project on a machine with Gradle/ForgeGradle available.
3. Run:
   gradlew setupDecompWorkspace
   gradlew build

The finished mod will be in:
build/libs/DewiersOverlay-1.0.0.jar

Note:
The included source is specifically for Minecraft Forge 1.8.9.
